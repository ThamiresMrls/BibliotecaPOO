package br.ufpb.dce.poo.persistencia;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;

import br.ufpb.dce.poo.projetopack.*;


public class Persistencia {
	
	private Biblioteca biblioteca = Biblioteca.getInstance();
	private Configuracao configuracao = Configuracao.getInstance();
	private static Persistencia singleton;
	
	private Persistencia() {
	}
	
	public static Persistencia getInstance(){
		if (singleton == null){
			singleton = new Persistencia();
		}
		
		return singleton;
	}
	
	public void gravarSistema() throws IOException{
		this.gravarConfiguracoesEmArquivo();
		for(Usuario usuario: this.biblioteca.getUsuarios()){
			usuario.gravarUsuarioEmArquivo();
		}
		Configuracao.getInstance().getBufferedWriterProfessor().close();
		Configuracao.getInstance().getBufferedWriterAluno().close();
		this.gravarLivrosEmArquivo();
		this.gravarEmprestimosEmArquivo();
	}
	
	public void carregarSistema() throws IOException, EmprestimoJaExisteException, UsuarioInexistenteException, LivroInexistenteException, UsuarioJaExisteException, MaximoDeLivrosEmprestadosException, UsuarioEmAtrasoException, QuantidadeDeLivrosInsuficienteException{
		
		Usuario aluno = new Aluno();
		Usuario professor = new Professor();
		this.carregarConfiguracoesDeArquivo();
		aluno.carregarUsuarioDeArquivo();
		professor.carregarUsuarioDeArquivo();
		this.carregarLivrosDeArquivo();
		this.carregarEmprestimosDeArquivo();
	}
	
	public void zerarSistema() throws UsuarioInexistenteException{
		Configuracao.getInstance().setDiasEmprestimoAluno(0);
		Configuracao.getInstance().setDiasEmprestimoProfessor(0);
		Configuracao.getInstance().setValorMulta(0);	
		this.biblioteca.getUsuarios().removeAll(this.biblioteca.getUsuarios());
		this.biblioteca.getLivros().removeAll(this.biblioteca.getLivros());
		this.biblioteca.getEmprestimosAtivos().removeAll(this.biblioteca.getEmprestimosAtivos());
	}

	public void gravarLivrosEmArquivo() throws IOException{
		BufferedWriter gravadorLivro = null;
		
		try{
			gravadorLivro = new BufferedWriter(new FileWriter(this.configuracao.getNomeArquivoLivros()));		
			for(Livro l: this.biblioteca.getLivros()){
				gravadorLivro.write(l.getNome());
				gravadorLivro.newLine();
				gravadorLivro.write(l.getCodigo());
				gravadorLivro.newLine();
				gravadorLivro.write(l.getAutor());
				gravadorLivro.newLine();
				gravadorLivro.write(l.getClassificacao());
				gravadorLivro.newLine();
				gravadorLivro.write(Integer.toString(l.getQuantidade()));
				gravadorLivro.newLine();
			}		
		}
		finally{
			if(gravadorLivro != null){
				gravadorLivro.close();
			}
		}
	}
	
	public void carregarLivrosDeArquivo()throws IOException {

		BufferedReader leitor = null; 
		try { 
			leitor = new BufferedReader(new FileReader(this.configuracao.getNomeArquivoLivros())); 
			String nomeDoLivro = null; 
			
			do { 
				nomeDoLivro = leitor.readLine();
				if (nomeDoLivro != null) {
					String codigo = leitor.readLine(); 
					String autor = leitor.readLine(); 
					String classificacao = leitor.readLine(); 
					int quantidade = Integer.parseInt(leitor.readLine());
					
					Livro l = new Livro (nomeDoLivro, codigo, autor,quantidade,classificacao); 
					this.biblioteca.cadastrarLivro(l); 
				} 
			} while (nomeDoLivro!= null); 
			
		} finally { 
			if (leitor != null) { 
				leitor.close(); 
			}
		}
	}
	
	public void gravarEmprestimosEmArquivo() throws IOException {
		BufferedWriter gravador = null;
		try {
			gravador = new BufferedWriter(new FileWriter(this.configuracao.getNomeArquivoEmprestimos()));
			for (Emprestimo e: this.biblioteca.getEmprestimosAtivos()){
				gravador.write(e.getUsuario().getMatricula());
				gravador.newLine();
				gravador.write(e.getLivro().getCodigo());
				gravador.newLine();
				
				gravador.write(Integer.toString(e.getDataEmprestimo().get(Calendar.DAY_OF_MONTH)));
				gravador.newLine();
				gravador.write(Integer.toString(e.getDataEmprestimo().get(Calendar.MONTH)));;
				gravador.newLine();
				gravador.write(Integer.toString(e.getDataEmprestimo().get(Calendar.YEAR)));
				gravador.newLine();
			
			}
		} finally {
			if (gravador!=null){
				gravador.close();
			}
		}		
	}
	
	public void carregarEmprestimosDeArquivo() throws IOException, EmprestimoJaExisteException, UsuarioInexistenteException, LivroInexistenteException, MaximoDeLivrosEmprestadosException, UsuarioEmAtrasoException, QuantidadeDeLivrosInsuficienteException{
		BufferedReader leitor = null;
		try {
			leitor = new BufferedReader(new FileReader(this.configuracao.getNomeArquivoEmprestimos()));
			String matricula = null;
			
			do {
				matricula = leitor.readLine();
				if (matricula != null){
					String codigoLivro = leitor.readLine();
					
					String diaEmprestimo = leitor.readLine();
					String mesEmprestimo = leitor.readLine();
					String anoEmprestimo = leitor.readLine();
			
					Usuario usuario = this.biblioteca.getUsuario(matricula);
					Livro livro = this.biblioteca.getLivro(codigoLivro);
					
					Calendar dataEmprestimo = Calendar.getInstance();
					dataEmprestimo.set(Integer.parseInt(anoEmprestimo),Integer.parseInt(mesEmprestimo),Integer.parseInt(diaEmprestimo));
					
					this.biblioteca.emprestarLivro(usuario, livro, dataEmprestimo);
					
				}
				
				
			} 
			while(matricula != null); 
		} 
		finally {
			if (leitor!=null){
				leitor.close();
			}
		}
		
	}
	
	public void gravarConfiguracoesEmArquivo() throws IOException{
		BufferedWriter gravador = null;
		try {  
			gravador = new BufferedWriter(new FileWriter(this.configuracao.getNomeArquivoConfiguracao()));
			gravador.write(Integer.toString(this.configuracao.getDiasEmprestimoAluno()));
			gravador.newLine();
			gravador.write(Integer.toString(this.configuracao.getDiasEmprestimoProfessor()));
			gravador.newLine();
			gravador.write(Double.toString(this.configuracao.getValorMulta()));
			gravador.newLine();
			gravador.write(Integer.toString(this.configuracao.getQuantidadeAlunos()));
			gravador.newLine();
			gravador.write(Integer.toString(this.configuracao.getQuantidadeProfessores()));
			gravador.newLine();
			gravador.write(this.configuracao.getNomeArquivoAlunos());
			gravador.newLine();
			gravador.write(this.configuracao.getNomeArquivoProfessores());
			gravador.newLine();
			gravador.write(this.configuracao.getNomeArquivoLivros());
			gravador.newLine();
			gravador.write(this.configuracao.getNomeArquivoEmprestimos());
			gravador.newLine();
			gravador.write(this.configuracao.getNomeArquivoConfiguracao());
			gravador.newLine();
		
		} finally {
			if (gravador!=null){
				gravador.close();
			}
		}
	}
	
	public void carregarConfiguracoesDeArquivo () throws IOException{
		BufferedReader leitor = null;
		
		try {
			leitor = new BufferedReader(new FileReader(this.configuracao.getNomeArquivoConfiguracao()));
			String diasEmprestimoAluno = null;
			
			do {
				diasEmprestimoAluno = leitor.readLine();
				if (diasEmprestimoAluno != null){
					String diasEmprestimoProfessor = leitor.readLine();
					String valorMulta = leitor.readLine();
					String quantidadeAlunos = leitor.readLine();
					String quantidadeProfessores = leitor.readLine();
					String nomeArquivoAlunos = leitor.readLine();
					String nomeArquivoProfessores = leitor.readLine();
					String nomeArquivoLivros = leitor.readLine();
					String nomeArquivoEmprestimos = leitor.readLine();
					String nomeArquivoConfiguracao = leitor.readLine();
					
					this.configuracao.setDiasEmprestimoAluno(Integer.parseInt(diasEmprestimoAluno));
					this.configuracao.setDiasEmprestimoProfessor(Integer.parseInt(diasEmprestimoProfessor));
					this.configuracao.setValorMulta(Double.parseDouble(valorMulta));
					this.configuracao.setQuantidadeAlunos(Integer.parseInt(quantidadeAlunos));
					this.configuracao.setQuantidadeProfessores(Integer.parseInt(quantidadeProfessores));
					this.configuracao.setNomeArquivoAlunos(nomeArquivoAlunos);
					this.configuracao.setNomeArquivoProfessores(nomeArquivoProfessores);
					this.configuracao.setNomeArquivoLivros(nomeArquivoLivros);
					this.configuracao.setNomeArquivoEmprestimos(nomeArquivoEmprestimos);
					this.configuracao.setNomeArquivoConfiguracao(nomeArquivoConfiguracao);

				}
				
				
			} 
			while(diasEmprestimoAluno != null); 
		} 
		finally {
			if (leitor!=null){
				leitor.close();
			}
		}
	}
 
}
