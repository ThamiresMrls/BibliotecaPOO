package br.ufpb.dce.poo.persistencia;

import java.io.IOException;

import br.ufpb.dce.poo.projetopack.UsuarioJaExisteException;



public interface UsuarioPersistente {
	
	public void gravarUsuarioEmArquivo() throws IOException;

	public void carregarUsuarioDeArquivo() throws IOException, UsuarioJaExisteException;
}
