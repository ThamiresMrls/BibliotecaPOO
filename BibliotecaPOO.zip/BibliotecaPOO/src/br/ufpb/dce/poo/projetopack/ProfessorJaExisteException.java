package br.ufpb.dce.poo.projetopack;

public class ProfessorJaExisteException extends Exception {
	public ProfessorJaExisteException(String msg){
		super(msg);
	}
}
