package br.ufpb.dce.poo.projetopack;

public class UsuarioEmAtrasoException extends Exception {
	public UsuarioEmAtrasoException (String msg){
		super(msg);
	}
}
