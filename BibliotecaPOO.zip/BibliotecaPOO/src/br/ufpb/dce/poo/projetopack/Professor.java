package br.ufpb.dce.poo.projetopack;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;


public class Professor extends Usuario{
	
	private String departamento;
	
	public Professor(){
		
	}

	public Professor(String nome, String matricula, String cpf, String departamento){
		super(nome, matricula, cpf);
		this.departamento = departamento;
		Configuracao.getInstance().setQuantidadeProfessores(Configuracao.getInstance().getQuantidadeProfessores	()+1);
	}
	
	public void setDepartamento(String departamento){
		this.departamento = departamento;
	}
	
	public String getDepartamento(){
		return this.departamento;
	}

	public int getQuantDiasEmprestimo() {
		return Configuracao.getInstance().getDiasEmprestimoProfessor();
	}

	@Override
	public void gravarUsuarioEmArquivo() throws IOException {
		BufferedWriter gravadorProfessor = null;
		try{
			gravadorProfessor = Configuracao.getInstance().getBufferedWriterProfessor();
			gravadorProfessor.write(super.getNome());
			gravadorProfessor.newLine();
			gravadorProfessor.write(super.getMatricula());
			gravadorProfessor.newLine();
			gravadorProfessor.write(super.getCPF());
			gravadorProfessor.newLine();
			gravadorProfessor.write(this.departamento);
			gravadorProfessor.newLine();
		}
		finally{
			
		}
		
	}

	@Override
	public void carregarUsuarioDeArquivo() throws IOException, UsuarioJaExisteException {
		Biblioteca biblioteca = Biblioteca.getInstance();
		BufferedReader leitorProfessor = null; 
		try{ 
			leitorProfessor = new BufferedReader(new FileReader (Configuracao.getInstance().getNomeArquivoProfessores())); 
			String nomeProfessor = null;
			do{ 
				nomeProfessor = leitorProfessor.readLine();
				if(nomeProfessor!= null){  
					String matriculaProfessor = leitorProfessor.readLine(); 
					String cpfProfessor = leitorProfessor.readLine(); 
					String departamento = leitorProfessor.readLine(); 
					Usuario usuario = new Professor(nomeProfessor, matriculaProfessor, cpfProfessor, departamento); 
					biblioteca.cadastrarUsuario(usuario); 
				} 
			} while(nomeProfessor != null); 
			
		} finally{ 
			if(leitorProfessor != null){ 
				leitorProfessor.close(); 
			} 
		} 
		
	}

}
