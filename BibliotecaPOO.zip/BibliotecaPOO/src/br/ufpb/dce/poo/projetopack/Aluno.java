package br.ufpb.dce.poo.projetopack;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;

public class Aluno extends Usuario{

	private String periodoIngresso;
	private String curso;

	public Aluno(){
		
	}
	
	public Aluno(String nome, String matricula, String cpf, String curso, String periodoIngresso){
		super(nome, matricula, cpf);
		this.periodoIngresso = periodoIngresso;
		this.curso = curso;
		Configuracao.getInstance().setQuantidadeAlunos(Configuracao.getInstance().getQuantidadeAlunos()+1);
	}
	
	public String getCurso (){
		return this.curso;
	}
	
	public String getPeriodoIngresso(){
		return this.periodoIngresso;
	}
	
	public int getQuantDiasEmprestimo() {
		return Configuracao.getInstance().getDiasEmprestimoAluno();
	}
	
	public void gravarUsuarioEmArquivo() throws IOException {
		BufferedWriter gravadorAluno = null;
		try{
			gravadorAluno = Configuracao.getInstance().getBufferedWriterAluno();
			gravadorAluno.write(super.getNome());
			gravadorAluno.newLine();
			gravadorAluno.write(super.getMatricula());
			gravadorAluno.newLine();
			gravadorAluno.write(super.getCPF());
			gravadorAluno.newLine();
			gravadorAluno.write(this.getPeriodoIngresso());
			gravadorAluno.newLine();
			gravadorAluno.write(this.getCurso());
			gravadorAluno.newLine();
		}
		finally{
			
		}

	} 

	@Override
	public void carregarUsuarioDeArquivo() throws  IOException, UsuarioJaExisteException {
		
		Biblioteca biblioteca = Biblioteca.getInstance();
		BufferedReader leitorAluno = null;
		
		try{
			leitorAluno = new BufferedReader(new FileReader(Configuracao.getInstance().getNomeArquivoAlunos()));
			String nomeAluno = null;
			do{
				nomeAluno = leitorAluno.readLine();
				if(nomeAluno != null){
					String matricula = leitorAluno.readLine();
					String cpf = leitorAluno.readLine();
					String periodoIngresso = leitorAluno.readLine();
					String curso = leitorAluno.readLine();
					Usuario u = new Aluno(nomeAluno, matricula, cpf, curso, periodoIngresso);
					biblioteca.cadastrarUsuario(u);
				}
			}while(nomeAluno != null);
		}
		finally{
			if(leitorAluno != null){
				leitorAluno.close();
			}
		}
		
	}

}
