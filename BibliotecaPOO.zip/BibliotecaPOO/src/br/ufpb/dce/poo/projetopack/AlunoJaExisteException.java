package br.ufpb.dce.poo.projetopack;

public class AlunoJaExisteException extends Exception {
	public AlunoJaExisteException(String msg){
		super(msg);
	}
}
