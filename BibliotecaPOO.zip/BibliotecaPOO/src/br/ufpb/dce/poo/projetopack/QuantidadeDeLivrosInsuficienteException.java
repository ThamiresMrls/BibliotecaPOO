package br.ufpb.dce.poo.projetopack;

public class QuantidadeDeLivrosInsuficienteException extends Exception {
	public QuantidadeDeLivrosInsuficienteException(String msg){
		super(msg);
	}
}
