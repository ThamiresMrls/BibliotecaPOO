package br.ufpb.dce.poo.projetopack;

import java.util.Calendar;
import java.util.List;


public class BibliotecaFacade {
	
	private Biblioteca biblioteca = Biblioteca.getInstance();
	
	public BibliotecaFacade(){
		
	}
	
	public void cadastrarUsuario(Usuario usuario) throws UsuarioJaExisteException{
		
		this.biblioteca.cadastrarUsuario(usuario);
	}
	
	public void cadastrarLivro(Livro livro){
		
		this.biblioteca.cadastrarLivro(livro);
		
	}
	
	public void removerUsuario(Usuario usuario) throws UsuarioInexistenteException{
		this.biblioteca.removerUsuario(usuario);
	}
	
	public void emprestarLivro(Usuario usuario, Livro livro, Calendar diaEmprestimo) throws MaximoDeLivrosEmprestadosException, UsuarioEmAtrasoException, QuantidadeDeLivrosInsuficienteException, UsuarioInexistenteException, LivroInexistenteException{
		this.biblioteca.emprestarLivro(usuario, livro, diaEmprestimo);
		
	}
	
	public Usuario pesquisarUsuario(String matricula) throws UsuarioInexistenteException{
		return this.biblioteca.getUsuario(matricula);
	}
	
	public Livro pesquisarLivro(String codigoLivro) throws LivroInexistenteException{
		return this.biblioteca.getLivro(codigoLivro);
	}
	
	public List<Usuario> pesquisarListaDeUsuarios(){
		return this.biblioteca.getUsuarios();
	}
	
	public List<Livro> pesquisarListaDeLivros(){
		return this.biblioteca.getLivros();
	}
	
	public List<Emprestimo> pesquisarListaDeEmprestimos(){
		return this.biblioteca.getEmprestimosAtivos();
	}
	
	public double calcularMulta(Usuario usuario) throws UsuarioInexistenteException{
		
		return this.biblioteca.calcularMulta(usuario);
		
	}
	
	public void devolverLivro(Usuario usuario, Livro livro) throws EmprestimoInexistenteException, UsuarioInexistenteException, LivroInexistenteException{
		
		this.biblioteca.devolverLivro(usuario, livro);
		
	}
	
}
