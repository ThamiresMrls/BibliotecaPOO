package br.ufpb.dce.poo.projetopack;

public class MaximoDeLivrosEmprestadosException extends Exception {
  public MaximoDeLivrosEmprestadosException (String msg){
	  super(msg);
	}
}
