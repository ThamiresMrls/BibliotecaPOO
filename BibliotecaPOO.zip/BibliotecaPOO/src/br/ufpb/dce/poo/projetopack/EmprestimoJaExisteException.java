package br.ufpb.dce.poo.projetopack;

public class EmprestimoJaExisteException extends Exception {
	public EmprestimoJaExisteException(String msg){
		super(msg);
	}
}
