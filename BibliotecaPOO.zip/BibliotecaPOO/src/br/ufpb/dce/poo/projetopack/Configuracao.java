package br.ufpb.dce.poo.projetopack;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Configuracao {
	private static Configuracao singleton;
	
	private double valorMulta;
	private int diasEmprestimoProfessor;
	private int diasEmprestimoAluno;
	private int quantidadeAlunos;
	private int quantidadeProfessores;
	private String nomeArquivoProfessores;
	private String nomeArquivoAlunos;
	private String nomeArquivoLivros;
	private String nomeArquivoEmprestimos;
	private String nomeArquivoConfiguracao;
	private BufferedWriter bufferedWriterAluno;
	private BufferedWriter bufferedWriterProfessor;
	
	private Configuracao (){
		this.valorMulta = 0;
		this.diasEmprestimoProfessor = 0;
		this.diasEmprestimoAluno = 0;
		this.quantidadeAlunos = 0;
		this.quantidadeProfessores = 0;
		this.nomeArquivoProfessores = "Professores.txt";
		this.nomeArquivoAlunos = "Alunos.txt";
		this.nomeArquivoLivros = "Livros.txt";
		this.nomeArquivoEmprestimos = "Emprestimos.txt";
		this.nomeArquivoConfiguracao = "Configura��es.txt";
	}
		
	public static Configuracao getInstance(){
		if (singleton == null){
			singleton = new Configuracao();
		}
		return singleton;
	}
	
	public int getDiasEmprestimoProfessor() {
		return this.diasEmprestimoProfessor;
	}

	public void setDiasEmprestimoProfessor(int diasEmprestimoProfessor) {
		this.diasEmprestimoProfessor = diasEmprestimoProfessor;
	}

	public void setDiasEmprestimoAluno(int diasEmprestimoAluno) {
		this.diasEmprestimoAluno = diasEmprestimoAluno;
	}
	
	public int getDiasEmprestimoAluno(){
		return this.diasEmprestimoAluno;
	}
	
	public void setValorMulta (double valor){
		this.valorMulta = valor;
	}
	
	public double getValorMulta (){
		return this.valorMulta;
	}
	
	public int getQuantidadeAlunos() {
		return this.quantidadeAlunos;
	}

	public void setQuantidadeAlunos(int quantidadeAlunos) {
		this.quantidadeAlunos = quantidadeAlunos;
	}
	
	public int getQuantidadeProfessores() {
		return this.quantidadeProfessores;
	}

	public void setQuantidadeProfessores(int quantidadeProfessores) {
		this.quantidadeProfessores = quantidadeProfessores;
	}
	
	public String getNomeArquivoProfessores() {
		return this.nomeArquivoProfessores;
	}

	public void setNomeArquivoProfessores(String nomeArquivoProfessores) {
		this.nomeArquivoProfessores = nomeArquivoProfessores;
	}

	public String getNomeArquivoAlunos() {
		return this.nomeArquivoAlunos;
	}

	public void setNomeArquivoAlunos(String nomeArquivoAlunos) {
		this.nomeArquivoAlunos = nomeArquivoAlunos;
	}

	public String getNomeArquivoLivros() {
		return this.nomeArquivoLivros;
	}

	public void setNomeArquivoLivros(String nomeArquivoLivros) {
		this.nomeArquivoLivros = nomeArquivoLivros;
	}

	public String getNomeArquivoEmprestimos() {
		return this.nomeArquivoEmprestimos;
	}

	public void setNomeArquivoEmprestimos(String nomeArquivoEmprestimos) {
		this.nomeArquivoEmprestimos = nomeArquivoEmprestimos;
	}

	public String getNomeArquivoConfiguracao() {
		return this.nomeArquivoConfiguracao;
	}

	public void setNomeArquivoConfiguracao(String nomeArquivoConfiguracao) {
		this.nomeArquivoConfiguracao = nomeArquivoConfiguracao;
	}
	
	public BufferedWriter getBufferedWriterAluno() throws IOException{
		if(this.bufferedWriterAluno == null){
			this.bufferedWriterAluno = new BufferedWriter(new FileWriter(this.nomeArquivoAlunos));
		}
		return this.bufferedWriterAluno;
	}
	
	public BufferedWriter getBufferedWriterProfessor() throws IOException{
		if(this.bufferedWriterProfessor == null){
			this.bufferedWriterProfessor = new BufferedWriter(new FileWriter(this.nomeArquivoProfessores));
		}
		return this.bufferedWriterProfessor;
	}
}
