package br.ufpb.dce.poo.projetopack;

public class UsuarioInexistenteException extends Exception {
	public UsuarioInexistenteException (String msg){
		super (msg);
	}
}
