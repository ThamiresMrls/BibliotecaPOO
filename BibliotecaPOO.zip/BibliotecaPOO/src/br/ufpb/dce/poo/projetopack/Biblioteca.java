package br.ufpb.dce.poo.projetopack;

import java.util.LinkedList;
import java.util.List;
import java.util.Calendar;


public class Biblioteca {
	
	private Configuracao configuracao = Configuracao.getInstance();
	private List<Livro> livros;
	private List<Emprestimo> emprestimosAtivos;
	private List<Usuario> usuarios;
	private static Biblioteca singleton;
	
	private Biblioteca() {
		this.livros = new LinkedList<Livro>();
		this.emprestimosAtivos = new LinkedList<Emprestimo>();
		this.usuarios = new LinkedList<Usuario>();
	}
	
	public static Biblioteca getInstance(){
		if (singleton == null){
			singleton = new Biblioteca();
		}
		return singleton;
	}
	
	public List<Usuario> getUsuarios(){
		return this.usuarios;
	}
	
	public List<Livro> getLivros(){
		return this.livros;
	}
	
	public List<Emprestimo> getEmprestimosAtivos(){
		return this.emprestimosAtivos;
	}
	
	public void cadastrarUsuario (Usuario u) throws UsuarioJaExisteException{
		for (Usuario usuario: this.usuarios){
			if (usuario.getMatricula().equals(u.getMatricula()) || usuario.getCPF().equals(u.getCPF())){
				throw new UsuarioJaExisteException ("Este usu�rio j� existe.");
			} 
		}
		this.usuarios.add(u);
	}
	
	public void cadastrarLivro(Livro livro){
		for (Livro lv: this.livros){
			if (lv.getCodigo().equals(livro.getCodigo())){
				lv.setQuantidade(lv.getQuantidade()+livro.getQuantidade());
			}
			
		}
		this.livros.add(livro);
	}
	
	public void removerUsuario(Usuario u) throws UsuarioInexistenteException{
		for (Usuario usuario: this.usuarios){
			if (usuario.getMatricula().equals(u.getMatricula())){
				this.usuarios.remove(u);
			} 
		}
		throw new UsuarioInexistenteException ("Este usu�rio n�o existe.");
	}
	
	public Usuario getUsuario(String matricula) throws UsuarioInexistenteException{
		
		for (Usuario u: this.usuarios){
			if (u.getMatricula().equals(matricula)){
				return u;
			}
		}
		throw new UsuarioInexistenteException ("Este usu�rio n�o existe.");
	}

	public Livro getLivro (String codigoLivro) throws LivroInexistenteException{
		for (Livro l: this.livros){
			if(l.getCodigo().equals(codigoLivro)){
				return l;
			}
		}
		throw new LivroInexistenteException ("Este livro n�o est� cadastrado");
	}
	
	public List<Emprestimo> listarEmprestimosEmAtraso(){
		
		List<Emprestimo> atrasos = new LinkedList<Emprestimo>();
		for (Emprestimo e: this.emprestimosAtivos){
			if (e.getDataDevolucao().before(Calendar.getInstance())){
				atrasos.add(e);
			}
		}
		return atrasos;
		
	}
	
	public double calcularMulta(Usuario u){
		
		long diasAtraso = 0;
		for (Emprestimo e: this.listarEmprestimosEmAtraso()){
			if (e.getUsuario().getMatricula().equals(u.getMatricula())){
				diasAtraso += this.diasEntre(e.getDataDevolucao(), Calendar.getInstance());
			}
			
		}
		return diasAtraso * this.configuracao.getValorMulta();
		
	}
	
	public long diasEntre(Calendar diaInicial, Calendar diaFinal){ 
		int tempoDia = 1000 * 60 * 60 * 24;
		long diferenca = diaFinal.getTimeInMillis() - diaInicial.getTimeInMillis();
		return diferenca / tempoDia;
		
	}
	
	public void emprestarLivro (Usuario usuario, Livro livro, Calendar dataEmprestimo) throws MaximoDeLivrosEmprestadosException, UsuarioEmAtrasoException, QuantidadeDeLivrosInsuficienteException{
		
		int quantidadeMaxEmprestimo = 3;
		int quantidadeMinimaLivros = 1;
		if (usuario.getEmprestimos().size() == quantidadeMaxEmprestimo){
			throw new MaximoDeLivrosEmprestadosException ("O usu�rio atingiu O limite de empr�stimos.");
		}
		for (Emprestimo e: this.listarEmprestimosEmAtraso()){
			if (e.getUsuario().getMatricula().equals(usuario.getMatricula())){
				throw new UsuarioEmAtrasoException ("O usu�rio est� em d�bito com a biblioteca.");
			}
		}
		for (Livro l: this.livros){
			if (l.getCodigo().equals(livro.getCodigo()) && l.getQuantidade() == quantidadeMinimaLivros){
				throw new QuantidadeDeLivrosInsuficienteException("Quantidade de livros insuficiente para empr�stimo.");
			}
		}
		int diaEmprestimo = dataEmprestimo.get(5);
		int mesEmprestimo = dataEmprestimo.get(2);
		int anoEmprestimo = dataEmprestimo.get(1);
		Calendar dataDevolucao = Calendar.getInstance();
		dataDevolucao.set(anoEmprestimo, mesEmprestimo, diaEmprestimo);
		dataDevolucao.add(dataDevolucao.DAY_OF_MONTH, usuario.getQuantDiasEmprestimo());
		Emprestimo novoEmprestimo = new Emprestimo (usuario, livro, dataEmprestimo, dataDevolucao);
		for (Livro lv: this.livros){
			if (lv.getCodigo().equals(livro.getCodigo())){
				lv.setQuantidade(lv.getQuantidade()-1);
			}
		}
		this.emprestimosAtivos.add(novoEmprestimo);
		usuario.adicionarEmprestimo(novoEmprestimo);	
		
	}
	
	public void devolverLivro (Usuario usuario, Livro livro)throws EmprestimoInexistenteException{
		boolean emprestou = false;
		for (Emprestimo emprestimoUsuario: usuario.getEmprestimos()){
			if (emprestimoUsuario.getLivro().getCodigo().equals(livro.getCodigo())){
				for (Emprestimo emprestimoBiblioteca: this.emprestimosAtivos){
					if (emprestimoBiblioteca.getLivro().getCodigo().equals(livro.getCodigo()) && emprestimoBiblioteca.getUsuario().getMatricula().equals(usuario.getMatricula())){
						this.emprestimosAtivos.remove(emprestimoBiblioteca);
						usuario.getEmprestimos().remove(emprestimoUsuario);
						emprestou = true;
						for (Livro lv : this.livros){
							if (lv.getCodigo().equals(livro.getCodigo())){
								lv.setQuantidade(lv.getQuantidade()+1);
							}
						}
					}
				}
			}
		}
		if (!(emprestou)){
			throw new EmprestimoInexistenteException ("O usu�rio n�o possui o empr�stimo referente.");
		}
		
	}
}



