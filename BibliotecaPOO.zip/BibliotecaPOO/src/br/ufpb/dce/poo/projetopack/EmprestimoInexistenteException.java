package br.ufpb.dce.poo.projetopack;

public class EmprestimoInexistenteException extends Exception {
	public EmprestimoInexistenteException(String msg){
		super(msg);
	}
}
