package br.ufpb.dce.poo.projetopack;

public class LivroInexistenteException extends Exception {
	public LivroInexistenteException (String msg){
		super(msg);
	}
}
