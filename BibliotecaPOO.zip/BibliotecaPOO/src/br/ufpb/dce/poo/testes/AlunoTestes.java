package br.ufpb.dce.poo.testes;

import br.ufpb.dce.poo.projetopack.*;

import junit.framework.TestCase;

public class AlunoTestes extends TestCase {
	private Aluno a = new Aluno("Anderson", "8121", "12345", "Sistemas de Informa��o", "2012.1");
	
	
	public void testNome(){
		assertEquals("Anderson", a.getNome());
	}
	
	public void testMatricula(){
		assertEquals("8121", a.getMatricula());
	}
	
	public void testCpf(){
		assertEquals("12345", a.getCPF());
	}
	
	public void testCurso() {
		assertEquals("Sistemas de Informa��o", a.getCurso());
	}
	
	public void testPriodoIngresso(){
		assertEquals("2012.1", a.getPeriodoIngresso());
	}
	
	public void testQuantDiasAluno(){
		Configuracao config = Configuracao.getInstance();
		config.setDiasEmprestimoAluno(10);
		assertEquals(10, a.getQuantDiasEmprestimo());
	}
}
