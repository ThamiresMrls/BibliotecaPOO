package br.ufpb.dce.poo.testes;

import java.util.Calendar;

import br.ufpb.dce.poo.projetopack.*;
import junit.framework.TestCase;

import org.junit.Test;

public class BibliotecaTestes extends TestCase {
	
	private Biblioteca bib = Biblioteca.getInstance();
	private BibliotecaFacade bibF = new BibliotecaFacade();	
	
	private Usuario aluno1 = new Aluno("Anderson","8121","12345","SI","2012.1");
	private Usuario aluno2 = new Aluno("Rys","8242","8787","SI","2012.1");
	private Usuario aluno3 = new Aluno("Odra","1010","1515","SI","2012.1");
	private Usuario aluno4 = new Aluno("Paulo","4040","8080","SI","2012.1");
	
	private Usuario prof1 = new Professor("Rodrigo", "21", "12", "DCE");
	private Usuario prof2 = new Professor("Ayla", "81", "34", "DCE");
	private Usuario prof3 = new Professor("Pedro","2020","3030","CCAE");
	
	private Livro livro1 = new Livro("Java", "0001", "Laudon", 3, "Programa��o");
	private Livro livro2 = new Livro("C�lculo I", "1030", "Chuck Norris", 50, "C�lculo");
	private Livro livro3 = new Livro("Banco de dados", "9087", "Date", 35, "Banco de dados");
	private Livro livro4 = new Livro("Redes de computadores", "4477", "Peter", 20, "Redes de computadores");
	
	public void testCadastrarUsuario() {
		
		try{
			this.bibF.cadastrarUsuario(this.aluno4);
			assertTrue(this.aluno4.equals(this.bibF.pesquisarUsuario("4040")));
		}catch(Exception e){
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testCadastrarUsuarioExistente(){
		try{
			this.bibF.cadastrarUsuario(this.aluno1);
		}catch(Exception e){
			assertEquals("Este usu�rio j� existe.", e.getMessage());
		}
	}

	@Test
	public void testCadastrarLivro() {
		try{
			this.bibF.cadastrarLivro(this.livro1);
			this.bibF.cadastrarLivro(this.livro2);
			assertEquals(livro1.getNome(), this.bibF.pesquisarLivro("0001").getNome());
			assertEquals(livro2.getNome(), this.bibF.pesquisarLivro("1030").getNome());
		}catch(Exception e){
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testCadastrarLivroExistente(){
		try{
			this.bibF.cadastrarLivro(this.livro1);
			assertEquals(6, this.bibF.pesquisarLivro(this.livro1.getCodigo()).getQuantidade());
		}catch(Exception e){
			fail(e.getMessage());
		}
	}

	@Test
	public void testGetLivro() {
		try{
			this.bibF.cadastrarLivro(livro2);
			assertEquals("1030", this.bibF.pesquisarLivro("1030").getCodigo());
			assertEquals("C�lculo I", this.bibF.pesquisarLivro("1030").getNome());
			assertEquals("Chuck Norris", this.bibF.pesquisarLivro("1030").getAutor());
		}catch(Exception e){
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testPesquisarUsuario(){
		try{
			this.bibF.cadastrarUsuario(aluno1);
			this.bibF.cadastrarUsuario(prof1);
			assertEquals("Rodrigo", this.bibF.pesquisarUsuario("21").getNome());
			assertEquals("12", this.bibF.pesquisarUsuario("21").getCPF());
			assertEquals("Anderson", this.bibF.pesquisarUsuario("8121").getNome());
			assertEquals("12345", this.bibF.pesquisarUsuario("8121").getCPF());
		}catch(Exception e){
			fail(e.getMessage());
		}
	}

	@Test
	public void testCalcularMulta() { 

		try{
			
			this.bibF.cadastrarUsuario(aluno3);
			this.bibF.cadastrarUsuario(prof3);
			
			Configuracao.getInstance().setDiasEmprestimoAluno(10);
			Configuracao.getInstance().setDiasEmprestimoProfessor(30);
			Configuracao.getInstance().setValorMulta(0.5);	
			Calendar dataEmprestimoAluno = Calendar.getInstance();
			Calendar dataEmprestimoProf = Calendar.getInstance();
			dataEmprestimoAluno.set(2014, 03, 16);
			
			this.bibF.emprestarLivro(this.aluno3, this.livro2, dataEmprestimoAluno);
			assertEquals(1.0, Biblioteca.getInstance().calcularMulta(this.aluno3));
			
			dataEmprestimoProf.set(2014, 02, 27);
			
			this.bibF.emprestarLivro(this.prof3, this.livro1, dataEmprestimoProf);
			assertEquals(1.0, Biblioteca.getInstance().calcularMulta(this.prof3));
		}catch(Exception e){
			fail(e.getMessage());
		}		
	}

	@Test
	public void testDiasEntre() {
		Calendar c1 = Calendar.getInstance();
		c1.set(2014, 03, 26);
		Calendar c2 = Calendar.getInstance();
		c2.set(2014, 4, 26);
		assertEquals(30, this.bib.diasEntre(c1, c2));
	}

	@Test
	public void testQuantidadeDeLivrosInsuficienteParaEmprestimo() {  
		try{
			Calendar diaEmprestimo = Calendar.getInstance();
			diaEmprestimo.set(2014, 4, 26);
			this.bibF.emprestarLivro(this.aluno1, this.livro1, diaEmprestimo);
		}
		catch(Exception e){
			assertEquals("Quantidade de livros insuficiente para empr�stimo.", e.getMessage());
		}
		
	}
	
	@Test
	public void testEmprestimoLivroAUsuario() {  
		try{
			Calendar diaEmprestimo = Calendar.getInstance();
			diaEmprestimo.set(2014, 4, 26);
			this.bibF.emprestarLivro(this.aluno1, this.livro1, diaEmprestimo);
			this.bibF.emprestarLivro(this.aluno1, this.livro1, diaEmprestimo);
			this.bibF.emprestarLivro(this.aluno1, this.livro2, diaEmprestimo);
			this.bibF.emprestarLivro(this.aluno1, this.livro2, diaEmprestimo);
		}
		catch(Exception e){
			assertEquals("Quantidade de livros insuficiente para empr�stimo.",e.getMessage());
		}
	}
	
	@Test
	public void testUsuarioComMaximoDeEmprestimos() {  
		try{
			Calendar diaEmprestimo = Calendar.getInstance();
			diaEmprestimo.set(2014, 4, 26);
			this.bibF.emprestarLivro(this.aluno1, this.livro2, diaEmprestimo);
			this.bibF.emprestarLivro(this.aluno1, this.livro2, diaEmprestimo);
			this.bibF.emprestarLivro(this.aluno1, this.livro2, diaEmprestimo);
			this.bibF.emprestarLivro(this.aluno1, this.livro2, diaEmprestimo);
		}
		catch(Exception e){
			assertEquals("O usu�rio atingiu O limite de empr�stimos.",e.getMessage());
		}
	}
	
	@Test
	public void testUsuarioEmDebito() {  
		try{
			Calendar diaEmprestimo = Calendar.getInstance();
			diaEmprestimo.set(2014, 3, 26);
			this.bibF.emprestarLivro(this.aluno2, this.livro2, diaEmprestimo);
		}
		catch(Exception e){
			assertEquals("O usu�rio est� em d�bito com a biblioteca.",e.getMessage());
		}
	}
	
	
	@Test
	public void testDatasAluno(){
		this.bibF.cadastrarLivro(this.livro3);
		
		Configuracao.getInstance().setDiasEmprestimoAluno(10);
		
		Calendar diaEmprestimo = Calendar.getInstance();
		diaEmprestimo.set(2014, 03, 27);
		
		try{
			this.bibF.emprestarLivro(this.aluno1, this.livro3, diaEmprestimo);
			this.bibF.emprestarLivro(this.aluno1, this.livro3, diaEmprestimo);
			for(Emprestimo emprestimo: this.aluno1.getEmprestimos()){
				assertEquals(10, this.bib.diasEntre(emprestimo.getDataEmprestimo(), emprestimo.getDataDevolucao()));
			}
		}catch(Exception e){
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testDatasProfessor(){
			this.bibF.cadastrarLivro(this.livro4);
			
			Configuracao.getInstance().setDiasEmprestimoProfessor(30);
			
			Calendar diaEmprestimo = Calendar.getInstance();
			diaEmprestimo.set(2014, 03, 20);
			try{
				this.bibF.emprestarLivro(this.prof2, this.livro4, diaEmprestimo);
				this.bibF.emprestarLivro(this.prof2, this.livro4, diaEmprestimo);
				for(Emprestimo emprestimo: this.prof2.getEmprestimos()){
					assertEquals(30, this.bib.diasEntre(emprestimo.getDataEmprestimo(), emprestimo.getDataDevolucao()));
				}
			}catch(Exception e){
				fail(e.getMessage());
			}
	}
	
	@Test
	public void testEmprestarLivroEDevolverLivro() {
		try{
			Livro livro5 = new Livro("Testes JUnit", "3590", "Fred", 2, "Programa��o");
			this.bibF.cadastrarLivro(livro5);
			Calendar diaEmprestimo = Calendar.getInstance();
			diaEmprestimo.set(2014, 04, 27);
			this.bibF.emprestarLivro(this.aluno1, livro5, diaEmprestimo);
			//Antes de emprestar tenho 2 livros de Gest�o, ap�s o empr�stimo fico com apenas 1!
			assertEquals(1, bib.getLivro("3590").getQuantidade());
			this.bibF.devolverLivro(this.aluno1, livro5);
			//Depois da devolu��o a quantidade de livros de Gest�o passa a ser 2!
			assertEquals(2, this.bib.getLivro("3590").getQuantidade());
		}
		catch(Exception e){
			fail(e.getMessage());
			
		}
		
	}
	
}
	

