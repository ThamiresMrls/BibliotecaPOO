package br.ufpb.dce.poo.testes;

import static org.junit.Assert.*;

import java.util.Calendar;

import org.junit.Test;

import br.ufpb.dce.poo.persistencia.Persistencia;
import br.ufpb.dce.poo.projetopack.*;

public class PersistenciaTestes {

	private BibliotecaFacade bib = new BibliotecaFacade();
	
	private Usuario al1 = new Aluno("Jo�o", "1234", "87654", "SI", "2013.1");
	private Usuario al2 = new Aluno("Maria", "1001", "88832", "SI", "2013.1");
	private Usuario prof1 = new Professor("Rodrigo", "8123", "45328", "DCE");
	private Usuario prof2 = new Professor("Chuck Norris", "4567", "98234", "DCE");
	private Livro l1 = new Livro("�lgebra Linear", "2245", "Albert", 20, "�lgebra");
	private Livro l2 = new Livro("Sistemas de Informa��o Gerenciais", "3345", "Laudon & Laudon", 40, "SI");
	
	
	@Test
	public void testGravarSistema(){
		try{
			Configuracao.getInstance().setDiasEmprestimoAluno(10);
			Configuracao.getInstance().setDiasEmprestimoProfessor(30);
			Configuracao.getInstance().setValorMulta(0.5);	
			Calendar dataEmprestimoAluno = Calendar.getInstance();
			Calendar dataEmprestimoProf = Calendar.getInstance();
			dataEmprestimoAluno.set(2014, 3, 28);
			dataEmprestimoProf.set(2014, 3, 27);
			this.bib.cadastrarUsuario(this.al1);
			this.bib.cadastrarUsuario(this.al2);
			this.bib.cadastrarUsuario(this.prof1);
			this.bib.cadastrarUsuario(this.prof2);
			this.bib.cadastrarLivro(this.l1);
			this.bib.cadastrarLivro(this.l2);
			this.bib.emprestarLivro(this.al1, this.l1, dataEmprestimoAluno);
			this.bib.emprestarLivro(this.al2, this.l2, dataEmprestimoAluno);
			this.bib.emprestarLivro(this.prof1, this.l1, dataEmprestimoProf);
			this.bib.emprestarLivro(this.prof2, this.l2, dataEmprestimoProf);
			
			assertEquals(4 ,this.bib.pesquisarListaDeUsuarios().size());
			assertEquals(2 ,this.bib.pesquisarListaDeLivros().size());
			assertEquals(4 ,this.bib.pesquisarListaDeEmprestimos().size());
			
			Persistencia.getInstance().gravarSistema();
		}catch(Exception e){
			fail(e.getMessage());
		}
	}
	
	@Test
	public void zerarSistema(){
		try{
			Persistencia.getInstance().zerarSistema();
			assertEquals(0 ,this.bib.pesquisarListaDeUsuarios().size());
			assertEquals(0 ,this.bib.pesquisarListaDeLivros().size());
			assertEquals(0 ,this.bib.pesquisarListaDeEmprestimos().size());
		}catch(Exception e){
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testCarregarSistema() throws UsuarioInexistenteException{
		Persistencia.getInstance().zerarSistema();
		try{
			Persistencia.getInstance().carregarSistema();
			assertEquals("Chuck Norris", this.bib.pesquisarUsuario("4567").getNome());
			assertEquals("�lgebra Linear" ,this.bib.pesquisarLivro("2245").getNome());
			assertEquals(4 ,this.bib.pesquisarListaDeUsuarios().size());
			assertEquals(2 ,this.bib.pesquisarListaDeLivros().size());
			assertEquals(4 ,this.bib.pesquisarListaDeEmprestimos().size());
		}catch(Exception e){
			fail(e.getMessage());
		}
	}

}
