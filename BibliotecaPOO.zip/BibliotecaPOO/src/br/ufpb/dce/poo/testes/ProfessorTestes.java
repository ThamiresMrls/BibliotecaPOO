package br.ufpb.dce.poo.testes;

import br.ufpb.dce.poo.projetopack.*;

import junit.framework.TestCase;

import org.junit.Test;

public class ProfessorTestes extends TestCase {
	
	private Professor professor = new Professor ("Rodrigo","333","09693265408","CCAE");

	public void testGetNome() {
		assertEquals("Rodrigo", professor.getNome());	
	}

	@Test
	public void testGetMatricula() {
		assertEquals("333", professor.getMatricula());
	
	}

	@Test
	public void testGetCPF() {
		assertEquals("09693265408", professor.getCPF());
		
	}

	public void testGetDepartamento() {
		assertEquals("CCAE",professor.getDepartamento());
		
	}
	public void testQuantDiasProfessor(){
		Configuracao config = Configuracao.getInstance();
		config.setDiasEmprestimoProfessor(30);
		assertEquals(30, professor.getQuantDiasEmprestimo());
	}

} 