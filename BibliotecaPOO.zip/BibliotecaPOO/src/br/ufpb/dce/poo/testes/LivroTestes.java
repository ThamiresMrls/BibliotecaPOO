package br.ufpb.dce.poo.testes;

import br.ufpb.dce.poo.projetopack.*;
import static org.junit.Assert.*;

import org.junit.Test;

public class LivroTestes {
	private Livro liv = new Livro("POO", "123", "Rodrigo", 0, "Programa��o");
	
	@Test
	public void testGetNome() {
		assertEquals("POO", this.liv.getNome());
	}

	@Test
	public void testGetCodigo() {
		assertEquals("123", this.liv.getCodigo());
	}

	@Test
	public void testGetESetQuantidade() {
		assertEquals(0, this.liv.getQuantidade());
		this.liv.setQuantidade(3);
		assertEquals(3, this.liv.getQuantidade());
	}


	@Test
	public void testGetAutor() {
		assertEquals("Rodrigo", this.liv.getAutor());
	}

	@Test
	public void testGetClassificacao() {
		assertEquals("Programa��o", this.liv.getClassificacao());
	}

}
